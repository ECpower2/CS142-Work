// main.cpp
//
// Launches the text editor

#include "FileViewer.h"

int main()
{
    FileViewer viewer;
    viewer.run();

    return 0;
}
